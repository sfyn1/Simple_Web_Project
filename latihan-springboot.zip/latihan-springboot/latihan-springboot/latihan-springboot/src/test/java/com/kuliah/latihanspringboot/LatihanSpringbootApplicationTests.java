package com.kuliah.latihanspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LatihanSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
